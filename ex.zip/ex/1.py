print('h')
print('g')
print('3')